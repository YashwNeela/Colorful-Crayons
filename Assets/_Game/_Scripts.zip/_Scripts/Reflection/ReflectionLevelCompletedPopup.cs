using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace TMKOC.Reflection{
public class ReflectionLevelCompletedPopup : LevelCompletedPopup
{
        protected override void OnGameWin()
        {
        
        }
    }
}