using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace TMKOC.Sorting
{
    public class DraggableUI2D : Draggable2D
    {
        

        public void OnSpawned()
        {
             m_isDragging = true;
             m_CanDrag = true;
             StartDragging();
            
        }
        
    }
}
